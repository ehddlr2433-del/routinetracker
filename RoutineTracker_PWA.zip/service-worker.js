/* RoutineTracker service worker
   - App shell (HTML/CSS/JS/icons) is pre-cached so the app opens offline after the first visit.
   - Pages: network first (fresh when online), cached copy when offline.
   - Static files: cached copy first, refreshed in the background.
   - Google Fonts: cached after first use.
   - Everything else (API / AI requests, other sites, POST) is never cached.
   Bump VERSION whenever you deploy changed files so phones pick up the update. */

const VERSION = 'rt-2026-10-04-2';
const SHELL = `${VERSION}-shell`;
const FONTS = `${VERSION}-fonts`;

const APP_SHELL = [
  './',
  './index.html',
  './style.css',
  './core.js',
  './script.js',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './maskable-192.png',
  './maskable-512.png',
  './apple-touch-icon.png',
  './favicon-32.png'
];

const STATIC_EXT = /\.(?:css|js|json|png|jpe?g|svg|webp|ico|woff2?|webmanifest)$/i;
const NEVER_CACHE = /\/(?:api|ai|auth)\//i;

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL);
    await cache.addAll(APP_SHELL.map(u => new Request(u, { cache: 'reload' })));
    // First install: take over right away. Updates wait for the user to tap "업데이트".
    if (!self.registration.active) await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => !k.startsWith(VERSION)).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (url.origin === self.location.origin) {
    if (NEVER_CACHE.test(url.pathname)) return;
    if (req.mode === 'navigate') { event.respondWith(networkFirstPage(req)); return; }
    if (STATIC_EXT.test(url.pathname)) { event.respondWith(staleWhileRevalidate(req, SHELL)); return; }
    return;
  }
  if (url.hostname === 'fonts.googleapis.com') { event.respondWith(staleWhileRevalidate(req, FONTS)); return; }
  if (url.hostname === 'fonts.gstatic.com') { event.respondWith(cacheFirst(req, FONTS)); return; }
  // other origins: pass through untouched
});

async function networkFirstPage(req) {
  const cache = await caches.open(SHELL);
  try {
    const res = await withTimeout(fetch(req), 4000);
    if (res && res.ok) cache.put('./index.html', res.clone());
    return res;
  } catch (e) {
    return (await cache.match(req, { ignoreSearch: true })) ||
           (await cache.match('./index.html')) ||
           (await cache.match('./')) ||
           new Response('<h1>오프라인</h1><p>인터넷에 연결된 뒤 다시 열어주세요.</p>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
  }
}

async function staleWhileRevalidate(req, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(req, { ignoreSearch: true });
  const network = fetch(req).then(res => {
    if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
    return res;
  }).catch(() => null);
  return cached || (await network) || Response.error();
}

async function cacheFirst(req, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(req);
  if (cached) return cached;
  try {
    const res = await fetch(req);
    if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
    return res;
  } catch (e) { return Response.error(); }
}

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
  });
}
