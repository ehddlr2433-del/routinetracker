/* =====================================================================
   UI layer — reads the central state, renders every tab, never decides.
   ===================================================================== */
(function(){
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const REDUCED=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
const KEY='routinetracker.demo.v1';
const TABS=['ai','today','routines','analytics','dna'];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=s=>esc(s).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/\n/g,'<br>');
const wait=ms=>new Promise(r=>setTimeout(r,REDUCED?0:ms));

let state=load()||RT.makeDemoState();
let current='ai',busy=false;
const pending={today:new Set(),routines:new Set(),analytics:new Set(),dna:new Set()};
const badge=new Set();
const prev=new Map();

function load(){try{const raw=localStorage.getItem(KEY);if(!raw)return null;const s=JSON.parse(raw);if(!s||s.v!==1||!Array.isArray(s.habits))return null;
  const keep={lastReport:s.analytics&&s.analytics.lastReport,weeklyReport:s.analytics&&s.analytics.weeklyReport};s.analytics=Object.assign(RT.computeAnalytics(s),keep);s.meta=s.meta||{nudged:{}};return s;}catch(e){return null;}}
let saveWarned=false;
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));saveWarned=false;}catch(e){
  if(!saveWarned){saveWarned=true;setTimeout(()=>toast('기기 저장 공간이 부족해서 기록이 저장되지 않았어요. 백업한 뒤 AI 대화 내역을 지워주세요.',null,6000),0);}}}
const habitById=id=>state.habits.find(h=>h.id===id);

/* ---------- apply pipeline (shared by chat, buttons and tab controls) ---------- */
const STRUCT=new Set(['UPDATE_HABIT','CREATE_HABIT','ADD_ROUTINE','MODIFY_ROUTINE','DELETE_HABIT','CHANGE_TIME','CHANGE_DURATION','LOWER_DIFFICULTY','INCREASE_DIFFICULTY','SET_GOAL']);
function applyActions(actions){
  const snap=actions.some(a=>STRUCT.has(a.type))?JSON.parse(JSON.stringify({habits:state.habits,routines:state.routines,experiments:state.experiments,user:state.user})):null;
  const changes=RT.ActionHandler.apply(state,actions);
  if(snap){const real=changes.filter(c=>!c.error&&(c.tab==='today'||c.tab==='routines'));if(real.length)state.meta.undo={at:Date.now(),label:real[0].text,more:real.length-1,data:snap};}
  if(changes.length){
    changes.forEach(c=>{if(c.tab&&pending[c.tab]){pending[c.tab].add(c.id||'*');if(c.tab!==current)badge.add(c.tab);}});
    ['analytics','dna'].forEach(t=>{if(t!==current)badge.add(t);});
    const tb=$('#tabbar');tb.classList.remove('sync');void tb.offsetWidth;tb.classList.add('sync');
  }
  save();renderAll();updateBadges();
  setTimeout(()=>{if(pending[current])pending[current].clear();},300);
  return changes;
}

/* ---------- tabs ---------- */
function showTab(tab){
  if(!TABS.includes(tab))return;const from=TABS.indexOf(current),to=TABS.indexOf(tab);
  $$('.screen').forEach(sc=>{const i=TABS.indexOf(sc.dataset.tab);sc.classList.toggle('active',sc.dataset.tab===tab);sc.classList.toggle('left',i<to);});
  $$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  current=tab;badge.delete(tab);
  if(tab!=='ai'){render(tab,true);setTimeout(()=>pending[tab]&&pending[tab].clear(),300);}
  else scrollChat();
  updateBadges();
  if(tab==='dna')startHelix();
}
function updateBadges(){$$('.tab').forEach(b=>b.classList.toggle('badge',badge.has(b.dataset.tab)));}
function renderAll(){['today','routines','analytics','dna'].forEach(t=>render(t,false));}
function render(tab,entering){
  const el=$('#'+tab);const fns={today:renderToday,routines:renderRoutines,analytics:renderAnalytics,dna:renderDNA};
  el.innerHTML=fns[tab]();
  if(entering){el.classList.remove('enter');void el.offsetWidth;el.classList.add('enter');}
  if(tab===current)animateIn(el);
  if(tab==='dna')setupHelix();
}
const fl=(tab,id)=>pending[tab]&&pending[tab].has(id)?' flash':'';

/* count-ups, rings and bars animate from their previous value */
function animateIn(root){
  $$('[data-count]',root).forEach(el=>{const k=el.dataset.key,to=+el.dataset.count,suf=el.dataset.suffix||'';const from=k&&prev.has(k)?prev.get(k):0;if(k)prev.set(k,to);
    if(REDUCED||from===to){el.textContent=to+suf;return;}const t0=performance.now(),D=750;
    const step=n=>{const p=Math.min(1,(n-t0)/D);el.textContent=Math.round(from+(to-from)*(1-Math.pow(1-p,3)))+suf;if(p<1)requestAnimationFrame(step);};el.textContent=from+suf;requestAnimationFrame(step);});
  $$('[data-anim]',root).forEach(el=>{const k=el.dataset.key,prop=el.dataset.anim,to=el.dataset.to;const from=k&&prev.has(k)?prev.get(k):el.dataset.from;if(k)prev.set(k,to);
    /* bars: set the final size once, then animate only transform (GPU, no layout work per frame) */
    if(prop==='width'||prop==='height'){
      const f=parseFloat(from)||0,t=parseFloat(to)||0;el.style[prop]=to;
      if(REDUCED||t<=0||f===t)return;
      const r=Math.min(f/t,4),ax=prop==='width'?'X':'Y';
      el.style.transition='none';el.style.transform=`scale${ax}(${r})`;
      requestAnimationFrame(()=>requestAnimationFrame(()=>{el.style.transition='';el.style.transform='none';}));
      return;
    }
    el.style[prop]=from;requestAnimationFrame(()=>requestAnimationFrame(()=>{el.style[prop]=to;}));});
}

/* ---------- TODAY ---------- */
function todayItems(){
  const T=RT.ymd(new Date()),dk=RT.dayOf(T);
  return state.routines.filter(r=>r.days.includes(dk)).sort((a,b)=>a.time.localeCompare(b.time))
    .map(r=>({r,h:habitById(r.habitId),log:state.routineLogs.find(l=>l.routineId===r.id&&l.date===T)})).filter(x=>x.h);
}
function renderToday(){
  const now=new Date();const items=todayItems();const done=items.filter(x=>x.log&&x.log.status==='done').length;const tot=items.length;
  const pct=tot?Math.round(done/tot*100):0;const C=2*Math.PI*44;const A=state.analytics;
  const next=items.find(x=>!x.log);
  let brief;
  if(!tot)brief='오늘은 예정된 루틴이 없어요. AI에게 새 습관을 말해보세요.';
  else if(!next)brief='오늘 루틴을 모두 마쳤어요. 내일도 같은 시간에 만나요.';
  else{const tr=A.topReason;brief=`다음 루틴은 <b>${RT.fmtTime(next.r.time)} ${esc(next.r.title)}</b>예요.`+(tr&&tr.key==='tired'?' 최근 피로로 놓친 날이 많아서, 오늘은 절반만 해도 성공으로 칠게요.':tr&&tr.key==='forgot'?' 깜빡하기 쉬운 시간이라 바로 앞 행동에 붙여보세요.':' 시작 2분만 넘기면 끝까지 가기 쉬워요.');}
  const runningExp=state.experiments.find(x=>x.status==='running');
  return `
  <div><div class="eyebrow">${now.getMonth()+1}월 ${now.getDate()}일 ${'일월화수목금토'[now.getDay()]}요일</div><h1 class="h1">오늘의 루틴</h1></div>
  <div class="card hero${fl('today','goal')}">
    <div class="ring"><svg viewBox="0 0 104 104"><circle class="bgc" cx="52" cy="52" r="44"/><circle class="fgc" cx="52" cy="52" r="44" stroke-dasharray="${C.toFixed(1)}" data-anim="strokeDashoffset" data-key="ring" data-from="${C.toFixed(1)}" data-to="${(C*(1-pct/100)).toFixed(1)}" style="stroke-dashoffset:${(C*(1-pct/100)).toFixed(1)}"/></svg>
      <div class="lbl"><div><b data-count="${pct}" data-suffix="%" data-key="todaypct">${pct}%</b><span>${done}/${tot} 완료</span></div></div></div>
    <div class="meta">
      <div class="btnrow"><span class="pill accent">🔥 연속 ${A.streak}일</span><span class="pill">이번 주 ${A.week.rate??0}%</span></div>
      <div class="goal">현재 목표<br><b>${esc(state.user.goal||'목표를 AI에게 말해주세요')}</b></div>
    </div>
  </div>
  <div class="card brief"><div class="orb sm pulse"></div><div><div class="eyebrow" style="margin-bottom:2px">AI 코치 브리핑</div><p>${brief}</p>${runningExp?`<p class="muted" style="margin-top:6px;font-size:13px">🧪 진행 중인 실험: ${esc(runningExp.title)}</p>`:''}</div></div>
  ${tot?`<div class="rlist">${items.map(({r,h,log})=>`
    <div class="ritem${log?' '+log.status:''}${fl('today',r.id)}" data-rid="${r.id}">
      <div class="hic" style="background:${h.color}22">${h.icon}</div>
      <div class="info"><b>${esc(r.title)}</b><span>${RT.fmtTime(r.time)} · ${esc(h.name)}${log&&log.status==='fail'&&log.reason?` · ${esc((RT.REASONS[log.reason]||{label:'기타'}).label)}`:''}</span></div>
      ${log?`<button class="status ${log.status}" data-act="undo" data-log="${log.id}" aria-label="기록 취소">${log.status==='done'?'✓ 완료':'✕ 못함'}</button>`
        :`<div class="ract"><button class="rb no" data-act="fail" data-rid="${r.id}" aria-label="못 했어요">✕</button><button class="rb ok" data-act="done" data-rid="${r.id}" aria-label="완료">✓</button></div>`}
    </div>`).join('')}</div>`
  :`<div class="card empty"><div class="orb"></div><p>아직 오늘 루틴이 없어요.<br>AI에게 "운동 습관 만들어줘"라고 말해보세요.</p><div class="btnrow" style="justify-content:center"><button class="btn primary" data-act="ask" data-fill="🏃 운동 습관 만들어줘">AI에게 요청하기</button><button class="btn" data-act="addform">＋ 직접 추가</button></div></div>`}`;
}

/* ---------- ROUTINES ---------- */
function renderRoutines(){
  const T=RT.ymd(new Date()),dk=RT.dayOf(T);
  const head=sub=>`<div class="tabhead"><div><div class="eyebrow">${sub}</div><h1 class="h1">루틴</h1></div><button class="btn primary sm" data-act="addform">＋ 직접 추가</button></div>`;
  if(!state.habits.length)return head('전체 습관')+`<div class="card empty"><div class="orb"></div><p>아직 습관이 없어요.<br>직접 추가하거나 AI에게 말해보세요.</p><div class="btnrow" style="justify-content:center"><button class="btn primary" data-act="addform">＋ 직접 추가</button><button class="btn" data-act="ask" data-fill="🌅 아침 루틴 만들어줘">AI에게 요청하기</button></div></div>`;
  return head(`전체 습관 ${state.habits.length}개 · 루틴 ${state.routines.length}개`)+
  state.habits.map(h=>{const rs=RT.routinesOf(state,h);const days=rs[0]?rs[0].days:[];
    const age=Math.max(0,Math.round((new Date(T)-new Date(h.createdAt))/864e5));const curDay=Math.min(7,age+1);const fresh=pending.routines.has(h.id);
    return `<div class="card hcard${fl('routines',h.id)}">
      <div class="hhead"><div class="hic" style="background:${h.color}22">${h.icon}</div><div class="info"><div style="display:flex;gap:8px;align-items:center"><b>${esc(h.name)}</b>${fresh?'<span class="newtag">AI</span>':''}</div><div class="sub">${esc(h.goal||'')}</div></div><span class="pill">${RT.DIFF_KO[h.difficulty]||''}</span></div>
      <div class="week">${RT.WEEK.map(d=>`<div class="wd${days.includes(d)?' on':''}${d===dk?' today':''}" style="${days.includes(d)?`background:${h.color}`:''}">${RT.DAY_KO[d]}</div>`).join('')}</div>
      <div>${rs.map(r=>`<div class="rline"><span class="tm">${r.time}</span><span class="tt">${esc(r.title)}</span>${r.duration?`<span class="pill">${r.duration}분</span>`:''}</div>`).join('')}</div>
      ${h.plan&&h.plan.length?`<div><div class="eyebrow" style="margin-bottom:6px">${age>=7?'7일 플랜 완주 · 유지 단계':`7일 플랜 · ${curDay}일째`}</div><div class="plan">${h.plan.map(p=>`<div class="pl${age<7&&p.day===curDay?' cur':''}${age<7&&p.day<curDay?' past':''}"><small>DAY ${p.day}</small><p>${esc(p.title)}</p></div>`).join('')}</div></div>`:''}
      <div class="hact"><button class="btn" data-act="editform" data-hid="${h.id}">✏️ 수정</button><button class="btn" data-act="delask" data-hid="${h.id}">🗑 삭제</button><button class="linkbtn" data-act="ask" data-fill="${esc(h.name)} 루틴을 조정하고 싶어">AI에게 요청 →</button></div>
    </div>`;}).join('');
}

/* ---------- CALENDAR HEATMAP ---------- */
const cal={offset:0,habit:'all',sel:null};
function dayStats(date,hid){
  const T=RT.ymd(new Date());const logs=state.routineLogs.filter(l=>l.date===date&&(hid==='all'||l.habitId===hid));
  const sched=date>T?0:state.routines.filter(r=>{const h=state.habits.find(x=>x.id===r.habitId);return h&&(hid==='all'||h.id===hid)&&h.createdAt<=date&&r.days.includes(RT.dayOf(date));}).length;
  return {logs,done:logs.filter(l=>l.status==='done').length,total:Math.max(logs.length,sched)};
}
function calendarHTML(){
  const now=new Date();const base=new Date(now.getFullYear(),now.getMonth()+cal.offset,1);const y=base.getFullYear(),m=base.getMonth();
  const nd=new Date(y,m+1,0).getDate();const lead=(base.getDay()+6)%7;const T=RT.ymd(now);
  let cells='',sumDone=0,perfect=0;
  for(let i=0;i<lead;i++)cells+='<div class="cell blank"></div>';
  for(let d=1;d<=nd;d++){const ds=RT.ymd(new Date(y,m,d));const st=dayStats(ds,cal.habit);sumDone+=st.done;
    let cls='';if(ds>T)cls='fut';else if(!st.total)cls='';else if(!st.done)cls='miss';else{const r=st.done/st.total;cls=r>=1?'l4':r>=.67?'l3':r>=.34?'l2':'l1';if(r>=1)perfect++;}
    cells+=`<button class="cell ${cls}${ds===T?' today':''}${cal.sel===ds?' sel':''}" data-act="calday" data-date="${ds}" aria-label="${m+1}월 ${d}일 ${st.done}/${st.total}">${d}</button>`;}
  let detail='';
  if(cal.sel){const st=dayStats(cal.sel,cal.habit);const [,mm,dd]=cal.sel.split('-');
    detail=`<div class="dayd"><b>${+mm}월 ${+dd}일 · ${st.done}/${st.total} 완료</b>${st.logs.length?st.logs.sort((a,b)=>(a.time||'').localeCompare(b.time||'')).map(l=>{const h=habitById(l.habitId);return `<div style="display:flex;gap:8px;align-items:center"><span class="pill ${l.status==='done'?'ok':'bad'}">${l.status==='done'?'✓':'✕'}</span><span style="flex:1;min-width:0">${h?h.icon:'•'} ${esc(l.title)}</span><span class="muted mono">${l.time||''}</span></div>`;}).join(''):'<span class="muted">기록이 없어요.</span>'}</div>`;}
  return `<div class="card"><div class="card-title"><div class="h2">📅 달력</div><div class="calnav"><button data-act="calnav" data-dir="-1" aria-label="이전 달">‹</button><b style="font-size:14px;min-width:84px;text-align:center">${y}년 ${m+1}월</b><button data-act="calnav" data-dir="1" aria-label="다음 달"${cal.offset>=0?' disabled style="opacity:.35"':''}>›</button></div></div>
    <div class="calfil"><button class="${cal.habit==='all'?'on':''}" data-act="calhabit" data-hid="all">전체</button>${state.habits.map(h=>`<button class="${cal.habit===h.id?'on':''}" data-act="calhabit" data-hid="${h.id}">${h.icon} ${esc(h.name)}</button>`).join('')}</div>
    <div class="cal">${['월','화','수','목','금','토','일'].map(x=>`<div class="dh">${x}</div>`).join('')}${cells}</div>
    <div class="legend2"><span>못 함</span><i style="border:1.5px dashed var(--bad);box-sizing:border-box"></i><span style="margin-left:4px">적음</span><i class="cell l1" style="padding:0"></i><i class="cell l2" style="padding:0"></i><i class="cell l3" style="padding:0"></i><i class="cell l4" style="padding:0"></i><span>많음</span><span style="margin-left:auto">완료 ${sumDone}회 · 완벽한 날 ${perfect}일</span></div>${detail}</div>`;
}

/* ---------- ANALYTICS ---------- */
function renderAnalytics(){
  const A=state.analytics;if(!A.total)return `<div><div class="eyebrow">실행 패턴</div><h1 class="h1">분석</h1></div><div class="card empty"><div class="orb"></div><p>실행 기록이 쌓이면 성공률과 실패 원인을 분석해드려요.</p></div>`;
  const bump=state.meta.reasonBump&&Date.now()-state.meta.reasonBump.at<15000?state.meta.reasonBump.reason:null;
  const reasons=Object.entries(A.reasons).sort((a,b)=>b[1]-a[1]);const maxR=reasons.length?reasons[0][1]:1;
  const lr=A.lastReport,wr=A.weeklyReport;
  const dayCols=RT.WEEK.map(d=>({d,v:A.byDay[d]}));const hard=A.hardestDay&&A.hardestDay.day;
  let bestD=null;dayCols.forEach(x=>{if(x.v&&(!bestD||x.v.rate>bestD.v.rate))bestD=x;});
  return `
  <div><div class="eyebrow">최근 ${A.total}개 실행 기록 기준</div><h1 class="h1">분석</h1></div>
  ${calendarHTML()}
  <div class="kpis${fl('analytics','kpi')}">
    <div class="kpi"><div class="k">전체 성공률</div><div class="v"><span data-count="${A.rate}" data-key="k-rate">${A.rate}</span><small>%</small></div></div>
    <div class="kpi"><div class="k">연속 실행</div><div class="v"><span data-count="${A.streak}" data-key="k-streak">${A.streak}</span><small>일</small></div></div>
    <div class="kpi"><div class="k">최근 7일</div><div class="v"><span data-count="${A.week.done}" data-key="k-week">${A.week.done}</span><small>/${A.week.total}</small></div></div>
  </div>
  ${lr?`<div class="card report${fl('analytics','report')}"><div class="card-title"><div class="h2">🧠 AI 분석 리포트</div><span class="pill accent">${timeAgo(lr.createdAt)}</span></div>
    <ul>${lr.bestHour!=null?`<li>⏰ 가장 성공률이 높은 시간 · <b>${RT.fmtTime(String(lr.bestHour).padStart(2,'0')+':00')}</b></li>`:''}${lr.hardestDay?`<li>📅 가장 어려운 요일 · <b>${RT.DAY_KO[lr.hardestDay]}요일</b></li>`:''}${lr.topReason?`<li>⚠️ 가장 많은 실패 원인 · <b>${esc(lr.topReason.label)}</b> (${lr.topReason.count}회)</li>`:''}</ul>
    <div class="insight">💡 ${esc(lr.insight)}</div></div>`
  :`<div class="card brief"><div class="orb sm pulse"></div><div style="flex:1"><p>AI에게 분석을 요청하면 패턴과 개선 방법을 리포트로 정리해드려요.</p><button class="linkbtn" data-act="ask" data-fill="📊 내 습관 분석해줘">내 습관 분석해줘 →</button></div></div>`}
  ${wr?`<div class="card${fl('analytics','weekly')}"><div class="card-title"><div class="h2">🗓 주간 리포트</div><span class="pill">${timeAgo(wr.createdAt)}</span></div><div class="statgrid"><div class="stat"><div class="k">완료</div><div class="v">${wr.week.done}<small>/${wr.week.total}</small></div></div><div class="stat"><div class="k">성공률</div><div class="v">${wr.week.rate}<small>%</small></div></div></div></div>`:''}
  <div class="card"><div class="card-title"><div class="h2">습관별 성공률</div></div><div class="bars">
    ${A.byHabit.map(b=>`<div class="bar${fl('analytics',b.habitId)}"><span class="nm">${b.icon} ${esc(b.name)}</span><div class="track"><div class="fill" style="background:${b.color};width:${b.rate||0}%" data-anim="width" data-key="hb-${b.habitId}" data-from="0%" data-to="${b.rate||0}%"></div></div><span class="val">${b.total?b.rate+'%':'신규'}</span></div>`).join('')}
  </div></div>
  <div class="card"><div class="card-title"><div class="h2">실패 원인</div><span class="pill bad">총 ${reasons.reduce((a,b)=>a+b[1],0)}회</span></div>
    ${reasons.length?`<div class="bars">${reasons.map(([k,v])=>`<div class="bar${fl('analytics','reason-'+k)}"><span class="nm">${esc((RT.REASONS[k]||{label:'기타'}).label)}${bump===k?'<span class="plus">+1</span>':''}</span><div class="track"><div class="fill" style="background:var(--bad);width:${Math.round(v/maxR*100)}%" data-anim="width" data-key="rs-${k}" data-from="0%" data-to="${Math.round(v/maxR*100)}%"></div></div><span class="val">${v}회</span></div>`).join('')}</div>`:'<p class="muted" style="margin:0">아직 실패 기록이 없어요.</p>'}
  </div>
  <div class="card"><div class="card-title"><div class="h2">실행 시간대</div>${A.bestBucket?`<span class="pill ok">${A.bestBucket.name} ${A.bestBucket.rate}%</span>`:''}</div>
    <div class="cols c4">${RT.BUCKETS.map(b=>{const v=A.byBucket[b];const r=v?v.rate:0;return `<div class="col${A.bestBucket&&A.bestBucket.name===b?' hi':''}"><span class="cv">${v?r+'%':'-'}</span><div class="cb" style="height:${r}%" data-anim="height" data-key="bk-${b}" data-from="0%" data-to="${r}%"></div><span class="cl">${b}<small>${{아침:'5–11시',낮:'11–17시',저녁:'17–21시',밤:'21–5시'}[b]}</small></span></div>`;}).join('')}</div></div>
  <div class="card"><div class="card-title"><div class="h2">요일별 패턴</div>${hard?`<span class="pill bad">${RT.DAY_KO[hard]}요일 취약</span>`:''}</div>
    <div class="cols">${dayCols.map(({d,v})=>{const r=v?v.rate:0;return `<div class="col${d===hard?' lo':''}${bestD&&bestD.d===d?' hi':''}"><span class="cv">${v?r:'-'}</span><div class="cb" style="height:${r}%" data-anim="height" data-key="dy-${d}" data-from="0%" data-to="${r}%"></div><span class="cl">${RT.DAY_KO[d]}</span></div>`;}).join('')}</div></div>`;
}
function timeAgo(t){const m=Math.round((Date.now()-t)/6e4);return m<1?'방금':m<60?`${m}분 전`:m<1440?`${Math.round(m/60)}시간 전`:`${Math.round(m/1440)}일 전`;}

/* ---------- DNA ---------- */
function dnaProfile(){
  const A=state.analytics;const b=A.bestBucket&&A.bestBucket.name;
  const persona={아침:'아침형 스타터',낮:'틈새 실행가',저녁:'저녁형 실행가',밤:'밤형 몰입가'}[b]||'탐색 중인 설계자';
  const sub={tired:'에너지 관리가 성패를 가르는 타입',forgot:'시작 신호가 필요한 타입',busy:'짧고 유연한 루틴이 맞는 타입',motivation:'작은 시작이 중요한 타입',social:'일정 변화에 민감한 타입'}[A.topReason&&A.topReason.key]||'데이터를 모으는 중';
  const burden=A.topReason?Math.round(((A.reasons.tired||0)+(A.reasons.burden||0))/Math.max(1,Object.values(A.reasons).reduce((a,c)=>a+c,0))*100):0;
  const morning=A.byBucket['아침']?A.byBucket['아침'].rate:0;
  const intensity=A.avgDuration!=null?Math.min(100,Math.round(A.avgDuration/45*100)):0;
  return {persona,sub,traits:[['꾸준함',A.consistency,'최근 14일 중 실행한 날'],['회복력',A.recovery??0,'실패 다음 기록이 성공인 비율'],['아침 친화도',morning,'아침 시간대 성공률'],['부담 민감도',burden,'피로·부담으로 인한 실패 비중'],['루틴 강도',intensity,'평균 루틴 길이 기준']]};
}
function renderDNA(){
  const A=state.analytics;const P=dnaProfile();
  const notes=[];
  if(A.bestHour)notes.push(`⏰ ${RT.fmtTime(String(A.bestHour.hour).padStart(2,'0')+':00')}에 시작한 루틴의 성공률이 ${A.bestHour.rate}%로 가장 높아요.`);
  if(A.hardestDay)notes.push(`📅 ${RT.DAY_KO[A.hardestDay.day]}요일 성공률은 ${A.hardestDay.rate}%예요. 주말 직전 피로가 쌓이는 패턴이 보여요.`);
  if(A.topReason)notes.push(`⚠️ 실패의 ${Math.round(A.topReason.count/Math.max(1,Object.values(A.reasons).reduce((a,c)=>a+c,0))*100)}%가 '${A.topReason.label}' 때문이에요.`);
  const weak=A.byHabit.filter(x=>x.total>=3).sort((a,b)=>a.rate-b.rate)[0];if(weak)notes.push(`🎯 가장 개선 여지가 큰 습관은 ${weak.icon} ${weak.name}(${weak.rate}%)이에요.`);
  const fresh=A.byHabit.filter(x=>x.total===0);fresh.forEach(x=>notes.push(`🌱 ${x.icon} ${x.name}: 새로 추가된 습관이라 첫 기록부터 DNA에 반영할게요.`));
  return `
  <div><div class="eyebrow">습관 DNA</div><h1 class="h1">나의 실행 패턴</h1></div>
  <div class="card dna-hero${fl('dna','persona')}"><canvas id="helix" aria-label="습관별 최근 14일 실행 기록 나선"></canvas>
    <div class="cap"><div class="eyebrow">AI가 파악한 유형</div><div class="persona">${P.persona}</div><div class="muted">${P.sub}</div>
      <div class="legend" style="margin-top:8px">${state.habits.map(h=>`<span><i style="background:${h.color}"></i>${esc(h.name)}</span>`).join('')}<span>● 성공 ○ 실패</span></div></div></div>
  <div class="card"><div class="card-title"><div class="h2">실행 특성</div></div><div class="traits">
    ${P.traits.map(([n,v,d],i)=>`<div class="trait"><div class="row"><b>${n}</b><span class="num"><span data-count="${v}" data-key="tr-${i}">${v}</span></span></div><div class="track"><div class="fill" style="background:linear-gradient(90deg,var(--accent),var(--accent-2));width:${v}%" data-anim="width" data-key="trw-${i}" data-from="0%" data-to="${v}%"></div></div><div class="muted" style="font-size:12px;margin-top:3px">${d}</div></div>`).join('')}
  </div></div>
  <div class="card"><div class="card-title"><div class="h2">🧠 AI 노트</div></div><ul class="notes">${notes.map(n=>`<li>${esc(n)}</li>`).join('')||'<li class="muted">기록이 쌓이면 패턴을 정리해드릴게요.</li>'}</ul></div>
  <div class="card"><div class="card-title"><div class="h2">🧪 AI 실험</div><span class="pill">진행 ${state.experiments.filter(x=>x.status!=='done').length} · 완료 ${state.experiments.filter(x=>x.status==='done').length}</span></div>
    ${state.experiments.length?state.experiments.map(x=>{if(x.status==='done'){const r=x.result||{};const dl=r.before!=null&&r.after!=null?r.after-r.before:null;
      return `<div class="exp${fl('dna',x.id)}"><div style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:14px">${esc(x.title)}</b><span class="pill ${dl==null?'':dl>=0?'ok':'bad'}">${dl==null?'완료':`${r.before}% → ${r.after}%`}</span></div><div class="muted" style="font-size:12.5px">가설: ${esc(x.hypothesis||'')}</div></div>`;}
      const d=Math.min(x.length,Math.max(1,Math.round((new Date(RT.ymd(new Date()))-new Date(x.startDate))/864e5)+1));return `<div class="exp${fl('dna',x.id)}"><div style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:14px">${esc(x.title)}</b><span class="pill accent">${d}/${x.length}일</span></div><div class="muted" style="font-size:12.5px">가설: ${esc(x.hypothesis||'')}</div><div class="track"><div class="fill" style="background:var(--accent);width:${Math.round(d/x.length*100)}%"></div></div></div>`;}).join('')
    :'<p class="muted" style="margin:0;font-size:14px">AI가 루틴을 조정하면 7일 실험이 여기에 기록돼요.</p>'}</div>`;
}
let helixRAF=0,helixPhase=0;
function setupHelix(){const c=$('#helix');if(!c)return;drawHelix();}
function startHelix(){cancelAnimationFrame(helixRAF);if(REDUCED){drawHelix();return;}const loop=()=>{if(current!=='dna')return;helixPhase+=.012;drawHelix();helixRAF=requestAnimationFrame(loop);};loop();}
function drawHelix(){
  const c=$('#helix');if(!c)return;const dpr=window.devicePixelRatio||1;const w=c.clientWidth,h=c.clientHeight;if(!w)return;
  if(c.width!==Math.round(w*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);}
  const g=c.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,w,h);
  const cs=getComputedStyle(document.documentElement);const line=cs.getPropertyValue('--line').trim()||'#ccc';const bg=cs.getPropertyValue('--surface').trim()||'#fff';
  const N=14,pad=22,step=(w-pad*2)/(N-1),mid=h/2,amp=h*.3;const now=new Date();
  const hs=state.habits;const days=[...Array(N)].map((_,i)=>RT.ymd(RT.addDays(now,i-(N-1))));
  for(let i=0;i<N;i++){const x=pad+i*step,a=i*.55+helixPhase;const y1=mid+Math.sin(a)*amp,y2=mid-Math.sin(a)*amp;
    g.strokeStyle=line;g.lineWidth=1.5;g.beginPath();g.moveTo(x,y1);g.lineTo(x,y2);g.stroke();
    hs.forEach((hb,j)=>{const t=hs.length>1?j/(hs.length-1):.5;const y=y1+(y2-y1)*t;const logs=state.routineLogs.filter(l=>l.habitId===hb.id&&l.date===days[i]);if(!logs.length)return;
      const ok=logs.some(l=>l.status==='done');const depth=(Math.cos(a)+1)/2;const r=2.6+depth*2.2;
      g.beginPath();g.arc(x,y,r,0,Math.PI*2);if(ok){g.fillStyle=hb.color;g.globalAlpha=.55+depth*.45;g.fill();}else{g.fillStyle=bg;g.fill();g.strokeStyle=hb.color;g.globalAlpha=.8;g.lineWidth=1.5;g.stroke();}g.globalAlpha=1;});}
  ['--accent','--accent-2'].forEach((v,k)=>{g.strokeStyle=cs.getPropertyValue(v).trim();g.lineWidth=2.5;g.beginPath();for(let x=pad;x<=w-pad+.5;x+=3){const a=((x-pad)/step)*.55+helixPhase;const y=mid+(k?-1:1)*Math.sin(a)*amp;x===pad?g.moveTo(x,y):g.lineTo(x,y);}g.stroke();});
}
window.addEventListener('resize',()=>{if(current==='dna')drawHelix();});

/* ---------- CHAT ---------- */
const chat=$('#chat'),input=$('#input'),sendBtn=$('#sendBtn');
function scrollChat(smooth){chat.scrollTo({top:chat.scrollHeight,behavior:smooth&&!REDUCED?'smooth':'auto'});}
function setChips(list){$('#chips').innerHTML=(list&&list.length?list:RT.DEFAULT_SUGGEST).map(t=>`<button class="chip" data-act="chip" data-fill="${esc(t)}">${esc(t)}</button>`).join('');}
function fillInput(t){input.value=t.replace(/^[^\w가-힣]+\s*/u,'').trim();autoGrow();sendBtn.disabled=!input.value.trim();if(current!=='ai')showTab('ai');input.focus();}
function autoGrow(){input.style.height='auto';input.style.height=Math.min(120,input.scrollHeight)+'px';}

function userEl(text,anim){const d=document.createElement('div');d.className='msg user'+(anim?'':' static');d.innerHTML=`<div class="bubble">${esc(text)}</div>`;return d;}
function cardsHTML(m){
  let html='';
  (m.cardsData||[]).forEach(cd=>{
    if(cd.type==='plan'&&cd.plan){html+=`<div class="mini"><h4>${cd.icon} ${esc(cd.name)} · 7일 루틴 ${cd.preview?'<span class="pill accent">미리보기</span>':''}<span class="pill" style="margin-left:auto">${RT.DIFF_KO[cd.difficulty]||''}</span></h4><div class="plan-days">${cd.plan.map((p,i)=>`<div class="pday" style="animation-delay:${.06*i}s"><b>D${p.day}</b><span>${esc(p.title.replace(/ \+.*/,''))}</span></div>`).join('')}</div>
      <div style="margin-top:8px">${cd.routines.map(r=>`<div class="rline"><span class="tm">${r.time}</span><span class="tt">${esc(r.title)}</span><span class="pill">${RT.fmtDays(r.days)}</span></div>`).join('')}</div></div>`;}
    if(cd.type==='report'&&cd.report){const r=cd.report;html+=`<div class="mini"><h4>📊 분석 요약</h4><div class="statgrid">
      <div class="stat"><div class="k">전체 성공률</div><div class="v"><span data-count="${r.overall}">${r.overall}</span><small>%</small></div></div>
      <div class="stat"><div class="k">연속 실행</div><div class="v"><span data-count="${r.streak}">${r.streak}</span><small>일</small></div></div>
      ${r.habits.filter(x=>x.total>=3).slice(0,4).map(x=>`<div class="stat"><div class="k">${x.icon} ${esc(x.name)}</div><div class="v"><span data-count="${x.rate}">${x.rate}</span><small>%</small></div></div>`).join('')}</div></div>`;}
    if(cd.type==='weekly'&&cd.report){const r=cd.report;html+=`<div class="mini"><h4>🗓 최근 7일</h4><div class="statgrid"><div class="stat"><div class="k">완료</div><div class="v"><span data-count="${r.week.done}">${r.week.done}</span><small>/${r.week.total}</small></div></div><div class="stat"><div class="k">성공률</div><div class="v"><span data-count="${r.week.rate}">${r.week.rate}</span><small>%</small></div></div></div></div>`;}
  });
  const ch=(m.changes||[]).filter(c=>!c.error);
  if(ch.length){const tabs=[...new Set(ch.map(c=>c.tab).filter(Boolean))];const nm={today:'오늘',routines:'루틴',analytics:'분석',dna:'DNA'};const sym={add:'+',update:'↻',remove:'−',log:'•'};
    html+=`<div class="mini changes"><h4>⚡ 앱에 반영된 변경 ${ch.length}건</h4><ul>${ch.map((c,i)=>`<li style="animation-delay:${.07*i}s"><span class="chg-ic ${c.kind}">${sym[c.kind]||'•'}</span><span>${esc(c.text)}</span></li>`).join('')}</ul>
      <div class="jump">${tabs.map(t=>`<button data-act="tab" data-tab="${t}">${nm[t]} 탭에서 보기 →</button>`).join('')}</div></div>`;}
  if(m.buttons&&m.buttons.length){html+=`<div class="${m.options?'optlist':'btnrow'}">${m.buttons.map((b,i)=>`<button class="btn${b.primary?' primary':''}${b.danger?' danger':''}" data-act="mbtn" data-mid="${m.id}" data-bi="${i}"${m.used&&(b.actions||b.after)?' disabled':''}>${esc(b.label)}</button>`).join('')}</div>`;}
  if(m.understanding){html+=`<details class="nlu"><summary>◇ AI 해석 · ${m.understanding.intent} · 신뢰도 ${m.understanding.confidence}%</summary><pre>${esc(JSON.stringify({understanding:m.understanding,actions:(m.actions||[]).map(a=>a.type==='CREATE_HABIT'?{type:a.type,habit:{name:a.habit.name,category:a.habit.category,difficulty:a.habit.difficulty}}:a)},null,2))}</pre></details>`;}
  return html;
}
function aiEl(m,anim){
  const d=document.createElement('div');d.className='msg ai'+(anim?'':' static');d.dataset.mid=m.id;
  d.innerHTML=`<div class="orb sm"></div><div class="body">${m.tag?`<span class="tagline">${esc(m.tag)}</span>`:''}<div class="bubble">${fmt(m.text)}</div><div class="extras">${anim?'':cardsHTML(m)}</div></div>`;
  return d;
}
function sysEl(text){const d=document.createElement('div');d.className='msg sys';d.innerHTML=`<div class="bubble">${esc(text)}</div>`;return d;}
function renderChat(){chat.innerHTML='';state.aiMessages.forEach(m=>chat.appendChild(m.role==='user'?userEl(m.text):m.role==='sys'?sysEl(m.text):aiEl(m,false)));const last=[...state.aiMessages].reverse().find(m=>m.role==='ai');setChips(last&&last.suggestions);scrollChat();}

async function typeInto(el,m){
  const bubble=$('.bubble',el);const plain=m.text.replace(/\*\*/g,'');
  if(!REDUCED){bubble.textContent='';const n=plain.length;const per=Math.max(6,Math.min(16,900/n));for(let i=0;i<n;i+=2){bubble.textContent=plain.slice(0,i+2);if(i%12===0)scrollChat();await new Promise(r=>setTimeout(r,per));}}
  bubble.innerHTML=fmt(m.text);
  const ex=$('.extras',el);ex.innerHTML=cardsHTML(m);animateIn(ex);scrollChat(true);
}
async function thinking(steps){
  const d=document.createElement('div');d.className='msg ai thinking';d.innerHTML=`<div class="orb sm live"></div><div class="body"><div class="steps"></div></div>`;chat.appendChild(d);scrollChat(true);
  const box=$('.steps',d);$('#headOrb').classList.add('live');
  for(let i=0;i<steps.length;i++){
    $$('.step',box).forEach(s=>{s.classList.remove('cur');const ic=s.querySelector('.ck');if(ic)ic.textContent='✓';});
    const s=document.createElement('div');s.className='step cur';s.innerHTML=`<span class="ck"></span><span class="shimmer">${esc(steps[i])}</span>`;box.appendChild(s);scrollChat(true);
    await wait(i===steps.length-1?420:620);
  }
  return d;
}
function snapCards(cards){return (cards||[]).map(c=>{
  if(c.type==='plan'&&c.plan)return c;
  if(c.type==='plan'){const h=state.habits.find(x=>x.key===c.habitKey);if(!h)return c;return {type:'plan',name:h.name,icon:h.icon,difficulty:h.difficulty,plan:h.plan,routines:RT.routinesOf(state,h).map(r=>({time:r.time,title:r.title,days:r.days}))};}
  if(c.type==='report')return {type:'report',report:state.analytics.lastReport};
  if(c.type==='weekly')return {type:'weekly',report:state.analytics.weeklyReport};
  return c;});}
let mid=0;const newId=()=>'m'+Date.now().toString(36)+(mid++);

async function postAI(m,{steps,animate=true}={}){
  let th=null;if(steps&&steps.length&&animate)th=await thinking(steps);
  const el=aiEl(m,animate);if(th)th.replaceWith(el);else chat.appendChild(el);$('#headOrb').classList.remove('live');
  state.aiMessages.push(m);if(state.aiMessages.length>120)state.aiMessages.splice(1,state.aiMessages.length-120);save();
  if(animate)await typeInto(el,m);scrollChat(true);
  setChips(m.suggestions);
  if(current!=='ai'){badge.add('ai');updateBadges();}
}

async function send(text){
  text=text.trim();if(!text||busy)return;busy=true;sendBtn.disabled=true;input.value='';autoGrow();
  const um={id:newId(),role:'user',text,at:Date.now()};state.aiMessages.push(um);chat.appendChild(userEl(text,true));scrollChat(true);
  try{
    const res=await RT.AIEngine.generateResponse(text,state);
    const pend=state.meta.pending;const pm=pend&&state.aiMessages.find(x=>x.id===pend.msgId);
    if(res.ui.accept&&pm&&!pm.used){const b=pm.buttons.find(x=>x.primary&&x.actions)||pm.buttons.find(x=>x.actions);
      if(b){await runButton(pm,b,{noBubble:true});busy=false;sendBtn.disabled=!input.value.trim();return;}}
    if(pm&&!pm.used&&(res.ui.deny||res.pending))markUsed(pm);
    const steps=res.ui.steps&&res.ui.steps.length?res.ui.steps:RT.STEPS.chat;
    const th=await thinking(steps);
    const changes=res.actions.length?applyActions(res.actions):[];
    const m={id:newId(),role:'ai',at:Date.now(),text:res.message,changes,buttons:res.ui.buttons||null,options:!!res.ui.options,suggestions:res.ui.suggestions||null,understanding:res.understanding,actions:res.actions.length?res.actions:(res.proposedActions||[]),cardsData:snapCards(res.ui.cards)};
    const el=aiEl(m,true);th.replaceWith(el);$('#headOrb').classList.remove('live');
    if(res.pending)state.meta.pending=Object.assign({msgId:m.id},res.pending);
    state.aiMessages.push(m);save();await typeInto(el,m);setChips(m.suggestions);
    if(changes.length&&res.ui.focus)toast(`AI가 앱을 업데이트했어요`,{label:'보기',fn:()=>showTab(res.ui.focus)});
    await checkProactive();
  }catch(err){console.error(err);await postAI({id:newId(),role:'ai',text:'요청을 처리하는 중에 문제가 생겼어요. 표현을 조금 바꿔서 다시 말해주세요.'},{animate:false});}
  busy=false;sendBtn.disabled=!input.value.trim();
}
async function checkProactive(){
  const p=RT.AIEngine.proactive(state);if(!p)return;
  RT.ActionHandler.apply(state,p.preActions||[]);save();await wait(500);
  const old=state.meta.pending&&state.aiMessages.find(x=>x.id===state.meta.pending.msgId);if(old&&!old.used)markUsed(old);
  const pmsg={id:newId(),role:'ai',at:Date.now(),text:p.message,tag:p.tag,buttons:p.buttons,suggestions:null};
  state.meta.pending={msgId:pmsg.id,intent:'NUDGE'};state.meta.lastWhy='최근 연속으로 놓친 기록이 쌓이면 루틴이 지금 컨디션보다 무겁다는 신호예요. 강도를 낮추면 다시 이어가기 쉬워지고, 7일 뒤에 결과를 보고 다시 올릴 수 있어요.';
  await postAI(pmsg,{steps:['🔍 실행 패턴 감지 중...'],animate:current==='ai'});
  if(current!=='ai')toast('AI 코치가 루틴 조정을 제안했어요',{label:'확인',fn:()=>showTab('ai')});
}
function markUsed(m){
  m.used=true;if(state.meta.pending&&state.meta.pending.msgId===m.id)state.meta.pending=null;
  const el=chat.querySelector(`[data-mid="${m.id}"]`);if(el)$$('.btn',el).forEach((x,i)=>{const bb=m.buttons&&m.buttons[+x.dataset.bi];if(!bb||bb.actions||bb.after)x.disabled=true;});save();
}
async function runButton(m,b,opt={}){
  if(b.fill){fillInput(b.fill);return;}
  if(m.used)return;markUsed(m);
  if(!opt.noBubble){chat.appendChild(userEl(b.label,true));state.aiMessages.push({id:newId(),role:'user',text:b.label,at:Date.now()});}
  let changes=[];if(b.actions&&b.actions.length){const th=await thinking(RT.STEPS.modify);changes=applyActions(b.actions);th.remove();}
  const a=b.after||{message:'좋아요.'};
  await postAI({id:newId(),role:'ai',at:Date.now(),text:a.message,changes,cardsData:snapCards(a.cards),actions:b.actions||[],suggestions:a.suggestions||null},{animate:true});
  if(changes.length&&a.focus)toast('AI가 앱을 업데이트했어요',{label:'보기',fn:()=>showTab(a.focus)});
  await checkProactive();
}

/* ---------- tab controls go through the same Action pipeline ---------- */
function burst(x,y,color){if(REDUCED)return;const cols=[color,'var(--accent)','var(--accent-2)','var(--ok)'];for(let i=0;i<16;i++){const p=document.createElement('i');p.className='burst';const ang=Math.random()*Math.PI*2,dist=40+Math.random()*50;
  p.style.cssText=`left:${x}px;top:${y}px;background:${cols[i%4]};--dx:${Math.cos(ang)*dist}px;--dy:${Math.sin(ang)*dist-20}px;--rot:${Math.random()*360}deg`;document.body.appendChild(p);setTimeout(()=>p.remove(),850);}}
function completeFromTab(rid,btn){
  const r=state.routines.find(x=>x.id===rid);const h=habitById(r.habitId);const rect=btn.getBoundingClientRect();
  applyActions([{type:'COMPLETE_ROUTINE',routineId:rid,date:RT.ymd(new Date())}]);
  burst(rect.left+rect.width/2,rect.top+rect.height/2,h.color);
  const row=$(`#today [data-rid="${rid}"]`);if(row)row.classList.add('justdone');
  const A=state.analytics;if(A.today.done===A.today.total&&A.today.total)toast('🎉 오늘 루틴을 모두 완료했어요!');
}
function openFailSheet(rid){
  const r=state.routines.find(x=>x.id===rid);const h=habitById(r.habitId);
  $('#sheetBody').innerHTML=`<div class="grab"></div><div><div class="eyebrow">${h.icon} ${esc(r.title)}</div><div class="h2" style="margin-top:2px">어떤 이유로 못 했나요?</div><p class="muted" style="margin:4px 0 0;font-size:13px">원인을 기록하면 AI가 루틴 조정에 활용해요.</p></div>
    <div class="reasons">${[['tired','😮‍💨 피곤했어요'],['busy','⏳ 시간이 없었어요'],['forgot','💭 깜빡했어요'],['motivation','😶 하기 싫었어요'],['sick','🤒 몸이 안 좋았어요'],['burden','🏋️ 너무 부담됐어요']].map(([k,l])=>`<button class="btn" data-act="reason" data-rid="${rid}" data-reason="${k}">${l}</button>`).join('')}</div>
    <button class="btn ghost" data-act="closesheet">취소</button>`;
  $('#sheet').hidden=false;
}
async function failFromTab(rid,reason){
  $('#sheet').hidden=true;const r=state.routines.find(x=>x.id===rid);const h=habitById(r.habitId);
  applyActions([{type:'FAIL_ROUTINE',routineId:rid,date:RT.ymd(new Date()),reason}]);
  const lbl=RT.REASONS[reason].label;
  state.aiMessages.push({id:newId(),role:'sys',text:`오늘 탭 · ${h.name} 실패 기록 (원인: ${lbl})`,at:Date.now()});chat.appendChild(sysEl(`오늘 탭 · ${h.name} 실패 기록 (원인: ${lbl})`));save();
  toast(`실패 원인 '${lbl}' 기록 · 분석에 반영됐어요`,{label:'분석',fn:()=>showTab('analytics')});
  await checkProactive();
}

let toastTimer=0;
function toast(text,action,ms){const t=$('#toast');t.innerHTML=`<span>${esc(text)}</span>${action?`<button>${esc(action.label)}</button>`:''}`;t.hidden=false;
  if(action)t.querySelector('button').onclick=()=>{t.hidden=true;action.fn();};
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>{t.hidden=true;},ms||3600);}

const FORM_ICONS=['✨','🎸','✍️','🎨','🍳','🧹','💊','💻','💰','🙏','🪴','📷','🏃','📖','💧','🧘'];
let iconTouched=false;
function openAddForm(){
  iconTouched=false;
  $('#sheetBody').innerHTML=`<div class="grab"></div><div><div class="h2">습관 직접 추가</div><p class="muted" style="margin:4px 0 0;font-size:13px">목록에 없는 습관도 만들 수 있어요. 7일 플랜은 자동으로 만들어져요.</p></div>
  <form class="form" id="addForm" novalidate>
    <label class="fl" for="f-name">이름<input id="f-name" maxlength="14" placeholder="예: 기타 연습, 일기 쓰기" autocomplete="off"></label>
    <div class="fl">아이콘<div class="icons">${FORM_ICONS.map((ic,i)=>`<button type="button" class="ico${i===0?' on':''}" data-ico="${ic}" aria-label="아이콘 ${ic}">${ic}</button>`).join('')}</div></div>
    <div class="row2"><label class="fl" for="f-time">시작 시간<input id="f-time" type="time" value="20:00"></label><label class="fl" for="f-dur">하루 몇 분<input id="f-dur" type="number" min="1" max="240" value="10" inputmode="numeric"></label></div>
    <div class="fl">요일<div class="days">${RT.WEEK.map(d=>`<button type="button" class="dy on" data-day="${d}">${RT.DAY_KO[d]}</button>`).join('')}</div></div>
    <p class="ferr" id="f-err" hidden></p>
    <button class="btn primary" type="submit">추가하기</button><button class="btn ghost" type="button" data-act="closesheet">취소</button>
  </form>`;
  $('#sheet').hidden=false;setTimeout(()=>$('#f-name')&&$('#f-name').focus(),250);
}
function submitAddForm(){
  const name=$('#f-name').value.trim().replace(/\s+/g,' ');const err=$('#f-err');
  const icon=($('.ico.on')||{}).dataset?.ico||'✨';const time=$('#f-time').value||'20:00';const dur=Math.round(+$('#f-dur').value);
  const days=$$('.dy.on').map(b=>b.dataset.day);
  const fail=m=>{err.textContent=m;err.hidden=false;};
  if(name.length<1)return fail('습관 이름을 입력해주세요.');
  if(!(dur>=1&&dur<=240))return fail('하루 시간은 1~240분 사이로 입력해주세요.');
  if(!days.length)return fail('요일을 하나 이상 골라주세요.');
  if(state.habits.some(h=>h.name===name))return fail(`'${name}' 습관이 이미 있어요. 수정은 AI에게 말해주세요.`);
  const level=dur<=10?'beginner':dur<=20?'intermediate':'advanced';
  const builtin=Object.values(RT.HABIT_DB).find(d=>d.name===name&&d.unit==='min');
  const B=builtin?RT.buildCreate(builtin.key,{difficulty:level,duration:dur,time,days}):RT.buildCreate(RT.customKey(name),{db:RT.customDb(name,{icon}),difficulty:level,duration:dur,time,days});
  if(!builtin)B.habit.icon=icon;
  applyActions(B.actions);
  $('#sheet').hidden=true;
  const note=`루틴 탭 · ${B.habit.icon} ${name} 직접 추가 (${RT.fmtDays(days)} ${RT.fmtTime(time)}, ${dur}분)`;
  state.aiMessages.push({id:newId(),role:'sys',text:note,at:Date.now()});chat.appendChild(sysEl(note));save();
  toast(`${B.habit.icon} ${name} 습관을 추가했어요`,{label:'오늘 보기',fn:()=>showTab('today')});
}
function openEditForm(hid){
  const h=habitById(hid);if(!h)return;const rs=RT.routinesOf(state,h);const r0=rs[0]||{time:'20:00',days:RT.WEEK.slice(),duration:null};
  const builtin=!!RT.HABIT_DB[h.key];const durOk=h.unit==='min'&&r0.duration;const icons=FORM_ICONS.includes(h.icon)?FORM_ICONS:[h.icon].concat(FORM_ICONS.slice(0,15));
  $('#sheetBody').innerHTML=`<div class="grab"></div><div><div class="h2">${h.icon} ${esc(h.name)} 수정</div><p class="muted" style="margin:4px 0 0;font-size:13px">${rs.length>1?`루틴 ${rs.length}개가 함께 옮겨져요.`:'저장하면 오늘·루틴·분석 탭에 바로 반영돼요.'}</p></div>
  <form class="form" id="editForm" data-hid="${h.id}" novalidate>
    <label class="fl" for="f-name">이름<input id="f-name" maxlength="14" value="${esc(h.name)}"${builtin?' disabled':''} autocomplete="off"></label>${builtin?'<p class="muted" style="margin:-8px 0 0;font-size:12px">기본 습관은 이름을 바꿀 수 없어요.</p>':''}
    <div class="fl">아이콘<div class="icons">${icons.map(ic=>`<button type="button" class="ico${ic===h.icon?' on':''}" data-ico="${ic}" aria-label="아이콘 ${ic}">${ic}</button>`).join('')}</div></div>
    <div class="row2"><label class="fl" for="f-time">${rs.length>1?'첫 루틴 시간':'시작 시간'}<input id="f-time" type="time" value="${r0.time}"></label>${durOk?`<label class="fl" for="f-dur">하루 몇 분<input id="f-dur" type="number" min="1" max="240" value="${r0.duration}" inputmode="numeric"></label>`:'<div></div>'}</div>
    <div class="fl">요일<div class="days">${RT.WEEK.map(d=>`<button type="button" class="dy${r0.days.includes(d)?' on':''}" data-day="${d}">${RT.DAY_KO[d]}</button>`).join('')}</div></div>
    <p class="ferr" id="f-err" hidden></p>
    <button class="btn primary" type="submit">저장하기</button><button class="btn ghost" type="button" data-act="closesheet">취소</button>
  </form>`;
  iconTouched=true;$('#sheet').hidden=false;
}
function submitEditForm(form){
  const h=habitById(form.dataset.hid);if(!h)return;const rs=RT.routinesOf(state,h);const r0=rs[0];const err=$('#f-err');const fail=m=>{err.textContent=m;err.hidden=false;};
  const name=$('#f-name').value.trim().replace(/\s+/g,' ');const icon=($('.ico.on')||{dataset:{}}).dataset.ico||h.icon;const time=$('#f-time').value;
  const durEl=$('#f-dur');const dur=durEl?Math.round(+durEl.value):null;const days=$$('.dy.on').map(b=>b.dataset.day);
  if(!name)return fail('습관 이름을 입력해주세요.');
  if(name!==h.name&&state.habits.some(x=>x!==h&&x.name===name))return fail(`'${name}' 습관이 이미 있어요.`);
  if(durEl&&!(dur>=1&&dur<=240))return fail('하루 시간은 1~240분 사이로 입력해주세요.');
  if(!days.length)return fail('요일을 하나 이상 골라주세요.');
  if(!time)return fail('시간을 입력해주세요.');
  const acts=[];const ch={};if(name!==h.name)ch.name=name;if(icon!==h.icon)ch.icon=icon;
  if(Object.keys(ch).length)acts.push({type:'UPDATE_HABIT',habitRef:h.id,changes:ch});
  if(r0&&time!==r0.time)acts.push({type:'CHANGE_TIME',habitRef:h.id,time});
  if(durEl&&r0&&dur!==r0.duration)acts.push({type:'CHANGE_DURATION',habitRef:h.id,duration:dur});
  if(r0&&days.join()!==r0.days.join())acts.push({type:'MODIFY_ROUTINE',habitRef:h.id,changes:{days}});
  $('#sheet').hidden=true;
  if(!acts.length){toast('바뀐 내용이 없어요');return;}
  applyActions(acts);
  sysNote(`루틴 탭 · ${icon} ${name} 직접 수정`);
  toast(`${icon} ${name} 수정했어요`,{label:'되돌리기',fn:undoDirect});
}
function openDeleteConfirm(hid){
  const h=habitById(hid);if(!h)return;const n=RT.routinesOf(state,h).length;const logs=state.routineLogs.filter(l=>l.habitId===h.id).length;
  $('#sheetBody').innerHTML=`<div class="grab"></div><div class="h2">${h.icon} ${esc(h.name)} 삭제할까요?</div><p class="muted" style="margin:0;font-size:14px">루틴 ${n}개가 함께 사라져요. 지난 실행 기록 ${logs}개는 전체 통계를 위해 남겨둬요.<br>삭제 직후에는 되돌릴 수 있어요.</p>
    <button class="btn danger" data-act="dodelete" data-hid="${h.id}">삭제하기</button><button class="btn ghost" data-act="closesheet">취소</button>`;
  $('#sheet').hidden=false;
}
function doDelete(hid){
  const h=habitById(hid);if(!h)return;const nm=`${h.icon} ${h.name}`;$('#sheet').hidden=true;
  applyActions([{type:'DELETE_HABIT',habitRef:h.id}]);if(cal.habit===hid)cal.habit='all';renderAll();
  sysNote(`루틴 탭 · ${nm} 삭제`);toast(`${nm} 삭제했어요`,{label:'되돌리기',fn:undoDirect});
}
function undoDirect(){if(!state.meta.undo){toast('되돌릴 변경이 없어요');return;}const lb=state.meta.undo.label;applyActions([{type:'RESTORE'}]);sysNote(`되돌리기 · ${lb}`);toast('되돌렸어요');}
function sysNote(t){state.aiMessages.push({id:newId(),role:'sys',text:t,at:Date.now()});chat.appendChild(sysEl(t));save();}
function openClearChat(){
  $('#sheetBody').innerHTML=`<div class="grab"></div><div class="h2">AI 대화 내역을 지울까요?</div><p class="muted" style="margin:0;font-size:14px">채팅 기록만 지워져요. 습관, 루틴, 실행 기록, 분석은 그대로 남아요.</p>
    <button class="btn danger" data-act="doclearchat">대화 내역 지우기</button><button class="btn ghost" data-act="closesheet">취소</button>`;
  $('#sheet').hidden=false;
}
function doClearChat(){
  state.aiMessages=[{id:newId(),role:'ai',at:Date.now(),text:V2(['대화 내역을 지웠어요. 습관과 기록은 그대로 있어요.\n무엇을 도와드릴까요?','깨끗하게 정리했어요. 루틴과 기록은 그대로예요.\n새로 이야기해볼까요?'])}];
  state.meta.pending=null;state.meta.lastWhy=null;state.meta.lastGreetDate=null;
  $('#sheet').hidden=true;save();renderChat();badge.delete('ai');updateBadges();showTab('ai');toast('AI 대화 내역을 지웠어요');
  setTimeout(maybeGreet,900);
}
const V2=a=>a[Math.floor(Math.random()*a.length)];
async function maybeGreet(){
  if(busy)return;const g=RT.AIEngine.greet(state);save();if(!g)return;
  if(g.preActions&&g.preActions.length)applyActions(g.preActions);
  const old=state.meta.pending&&state.aiMessages.find(x=>x.id===state.meta.pending.msgId);if(old&&!old.used&&g.buttons)markUsed(old);
  const gm={id:newId(),role:'ai',at:Date.now(),text:g.message,tag:g.tag,buttons:g.buttons||null,suggestions:g.suggestions||null};
  if(g.buttons&&g.buttons.some(b=>b.actions))state.meta.pending={msgId:gm.id,intent:'GREET'};
  if(g.why)state.meta.lastWhy=g.why;
  busy=true;await postAI(gm,{steps:['🔍 어제 기록 살펴보는 중...','🧠 오늘 브리핑 준비 중...'],animate:current==='ai'});busy=false;
}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')setTimeout(maybeGreet,600);});
function openReset(){
  const n=state.habits.length,m=state.routineLogs.length;
  $('#sheetBody').innerHTML=`<div class="grab"></div><div><div class="h2">데이터 관리</div><p class="muted" style="margin:4px 0 0;font-size:13px">기록은 이 브라우저에만 저장돼요 (습관 ${n}개 · 기록 ${m}개). 백업해두면 다른 기기로 옮길 수 있어요.</p></div>
    ${canOfferInstall()?'<button class="btn" data-act="install">📲 홈 화면에 앱 설치</button><div class="sep"></div>':''}
    <button class="btn primary" data-act="export">백업 파일 저장</button>
    <button class="btn" data-act="copybackup">백업 코드 복사</button>
    <label class="btn" for="f-import" style="cursor:pointer">백업 파일 불러오기</label><input type="file" id="f-import" accept=".json,application/json,text/plain" hidden>
    <button class="btn" data-act="pasteform">백업 코드 붙여넣기</button>
    <div class="sep"></div>
    <button class="btn" data-act="clearchat">💬 AI 대화 내역만 지우기</button>
    <p class="muted" style="margin:0;font-size:12.5px">파일 저장이 안 되는 화면에서는 '백업 코드 복사'를 메모장 등에 붙여넣어 보관하세요.</p>
    <div class="sep"></div>
    <button class="btn" data-act="reset" data-mode="demo">샘플 기록으로 다시 시작</button><button class="btn" data-act="reset" data-mode="empty">빈 상태로 시작</button><button class="btn ghost" data-act="closesheet">닫기</button>`;
  $('#sheet').hidden=false;
}
function backupText(){return JSON.stringify({app:'RoutineTracker',version:1,exportedAt:new Date().toISOString(),state},null,0);}
async function exportFile(){
  const txt=backupText();const name=`routinetracker-backup-${RT.ymd(new Date())}.json`;
  /* iPhone: a download link inside a home-screen app opens a dead-end preview, so use the share sheet ("파일에 저장") */
  if(IS_IOS&&navigator.canShare&&typeof File==='function'){
    try{const file=new File([txt],name,{type:'application/json'});
      if(navigator.canShare({files:[file]})){await navigator.share({files:[file],title:'RoutineTracker 백업'});$('#sheet').hidden=true;toast('공유 메뉴에서 "파일에 저장"을 고르면 백업이 보관돼요.',null,5000);return;}
    }catch(e){if(e&&e.name==='AbortError')return;}
  }
  try{const blob=new Blob([txt],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},1000);
    toast('백업 파일을 저장했어요. 저장이 안 됐다면 백업 코드 복사를 써주세요.');}catch(e){copyBackup();}
}
function copyBackup(){
  const txt=backupText();
  const show=()=>{$('#sheetBody').innerHTML=`<div class="grab"></div><div class="h2">백업 코드</div><p class="muted" style="margin:0;font-size:13px">아래 내용을 전부 선택해 복사한 뒤 메모장 등에 보관하세요.</p><textarea id="f-backup" readonly>${esc(txt)}</textarea><button class="btn ghost" data-act="closesheet">닫기</button>`;$('#sheet').hidden=false;const ta=$('#f-backup');ta.focus();ta.select();};
  try{navigator.clipboard.writeText(txt).then(()=>{toast('백업 코드를 복사했어요. 메모장 등에 붙여넣어 보관하세요.');$('#sheet').hidden=true;},show);}catch(e){show();}
}
function openPasteForm(){
  $('#sheetBody').innerHTML=`<div class="grab"></div><div class="h2">백업 코드 붙여넣기</div><label class="fl" for="f-paste">백업 코드<textarea id="f-paste" placeholder="복사해둔 백업 코드를 붙여넣으세요"></textarea></label><p class="ferr" id="f-err" hidden></p><button class="btn primary" data-act="pasteimport">불러오기</button><button class="btn ghost" data-act="closesheet">취소</button>`;
  $('#sheet').hidden=false;
}
let pendingImport=null;
function parseBackup(text){
  let o;try{o=JSON.parse(text);}catch(e){return {error:'백업 내용을 읽을 수 없어요. 코드 전체를 빠짐없이 붙여넣었는지 확인해주세요.'};}
  const st=o&&o.state?o.state:o;
  if(!st||st.v!==1||!Array.isArray(st.habits)||!Array.isArray(st.routines)||!Array.isArray(st.routineLogs))return {error:'RoutineTracker 백업 형식이 아니에요.'};
  return {state:st};
}
function confirmImport(text){
  const r=parseBackup(text);
  if(r.error){const err=$('#f-err');if(err){err.textContent=r.error;err.hidden=false;}else{toast(r.error);}return;}
  pendingImport=r.state;
  $('#sheetBody').innerHTML=`<div class="grab"></div><div class="h2">백업을 불러올까요?</div><p class="muted" style="margin:0;font-size:14px">백업: 습관 ${r.state.habits.length}개 · 기록 ${r.state.routineLogs.length}개<br>지금 데이터(습관 ${state.habits.length}개 · 기록 ${state.routineLogs.length}개)는 백업 내용으로 바뀌어요.</p><button class="btn primary" data-act="doimport">불러오기</button><button class="btn ghost" data-act="closesheet">취소</button>`;
  $('#sheet').hidden=false;
}
function doImport(){
  if(!pendingImport)return;const st=pendingImport;pendingImport=null;
  const base=RT.makeEmptyState();
  state=Object.assign(base,st,{user:Object.assign(base.user,st.user||{}),meta:Object.assign(base.meta,st.meta||{}),failureReasons:st.failureReasons||[],experiments:st.experiments||[],aiMessages:Array.isArray(st.aiMessages)?st.aiMessages:[]});
  const keep={lastReport:st.analytics&&st.analytics.lastReport,weeklyReport:st.analytics&&st.analytics.weeklyReport};state.analytics=Object.assign(RT.computeAnalytics(state),keep);
  state.aiMessages.push({id:newId(),role:'sys',text:`백업을 불러왔어요 · 습관 ${state.habits.length}개 · 기록 ${state.routineLogs.length}개`,at:Date.now()});
  Object.values(pending).forEach(x=>x.clear());badge.clear();prev.clear();
  $('#sheet').hidden=true;save();renderAll();renderChat();updateBadges();showTab('routines');
  toast('백업을 불러왔어요');
}
function reset(mode){
  state=mode==='empty'?Object.assign(RT.makeEmptyState(),{aiMessages:[{id:'welcome',role:'ai',at:Date.now(),text:'안녕하세요, RoutineTracker AI예요.\n아직 등록된 습관이 없어요. 만들고 싶은 습관을 편하게 말해주세요.\n예: "요즘 운동을 시작하고 싶은데 계속 미루게 돼"'}]}):RT.makeDemoState();
  if(mode==='empty')state.analytics=RT.computeAnalytics(state);
  Object.values(pending).forEach(s=>s.clear());badge.clear();prev.clear();
  $('#sheet').hidden=true;save();renderAll();renderChat();updateBadges();showTab('ai');
  setTimeout(maybeGreet,900);
}

/* ---------- events ---------- */
document.addEventListener('click',e=>{
  const ic=e.target.closest('.ico');if(ic){$$('.ico').forEach(x=>x.classList.toggle('on',x===ic));iconTouched=true;return;}
  const dy=e.target.closest('.dy');if(dy){dy.classList.toggle('on');return;}
  const b=e.target.closest('[data-act],.tab');if(!b)return;
  if(b.classList.contains('tab')){showTab(b.dataset.tab);return;}
  const act=b.dataset.act;
  if(act==='chip'||act==='ask')fillInput(b.dataset.fill);
  else if(act==='tab')showTab(b.dataset.tab);
  else if(act==='done')completeFromTab(b.dataset.rid,b);
  else if(act==='fail')openFailSheet(b.dataset.rid);
  else if(act==='reason')failFromTab(b.dataset.rid,b.dataset.reason);
  else if(act==='undo')applyActions([{type:'UNDO_LOG',logId:b.dataset.log}]);
  else if(act==='closesheet')$('#sheet').hidden=true;
  else if(act==='reset')reset(b.dataset.mode);
  else if(act==='addform')openAddForm();
  else if(act==='export')exportFile();
  else if(act==='copybackup')copyBackup();
  else if(act==='pasteform')openPasteForm();
  else if(act==='pasteimport')confirmImport($('#f-paste').value);
  else if(act==='doimport')doImport();
  else if(act==='editform')openEditForm(b.dataset.hid);
  else if(act==='delask')openDeleteConfirm(b.dataset.hid);
  else if(act==='dodelete')doDelete(b.dataset.hid);
  else if(act==='clearchat')openClearChat();
  else if(act==='doclearchat')doClearChat();
  else if(act==='calnav'){cal.offset=Math.min(0,cal.offset+(+b.dataset.dir));cal.sel=null;render('analytics',false);}
  else if(act==='calhabit'){cal.habit=b.dataset.hid;render('analytics',false);}
  else if(act==='calday'){cal.sel=cal.sel===b.dataset.date?null:b.dataset.date;render('analytics',false);}
  else if(act==='mbtn'){const m=state.aiMessages.find(x=>x.id===b.dataset.mid);if(m&&m.buttons)runButton(m,m.buttons[+b.dataset.bi]);}
});
$('#sheet').addEventListener('click',e=>{if(e.target.id==='sheet')$('#sheet').hidden=true;});
$('#resetBtn').addEventListener('click',openReset);
document.addEventListener('submit',e=>{if(e.target.id==='addForm'){e.preventDefault();submitAddForm();}else if(e.target.id==='editForm'){e.preventDefault();submitEditForm(e.target);}});
document.addEventListener('input',e=>{if(e.target.id==='f-name'&&!iconTouched){const ic=RT.guessIcon(e.target.value);$$('.ico').forEach(x=>x.classList.toggle('on',x.dataset.ico===ic));}});
document.addEventListener('change',e=>{if(e.target.id==='f-import'&&e.target.files[0]){const fr=new FileReader();fr.onload=()=>confirmImport(String(fr.result));fr.readAsText(e.target.files[0]);e.target.value='';}});
input.addEventListener('input',()=>{autoGrow();sendBtn.disabled=busy||!input.value.trim();});
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){if(e.isComposing||e.keyCode===229)return;e.preventDefault();send(input.value);}});
sendBtn.addEventListener('click',()=>send(input.value));

renderAll();renderChat();updateBadges();
/* =====================================================================
   Mobile & PWA layer
   - visible-viewport sizing (iOS Safari address bar, on-screen keyboard)
   - install button (Android prompt / iPhone instructions)
   - service worker registration + "new version" prompt
   ===================================================================== */
const UA=navigator.userAgent||'';
const IS_IOS=/iP(hone|ad|od)/.test(UA)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
const IS_SAMSUNG=/SamsungBrowser/i.test(UA);
const isStandalone=()=>(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;
const IS_WEB=/^https?:$/.test(location.protocol);

/* --- 1. keep the app exactly inside the visible area, and lift the composer above the keyboard --- */
(function(){
  const app=$('#app'),root=document.documentElement,vv=window.visualViewport;let raf=0,baseH=0;
  const isField=el=>!!el&&(el.tagName==='TEXTAREA'||(el.tagName==='INPUT'&&!/^(button|checkbox|radio|file|submit|range|color)$/i.test(el.type)));
  function fit(){
    raf=0;
    const h=Math.round(vv?vv.height:window.innerHeight);
    const top=vv?Math.max(0,Math.round(vv.offsetTop)):0;
    const typing=isField(document.activeElement);
    if(!typing||!baseH)baseH=Math.max(baseH,h);
    root.style.setProperty('--app-h',h+'px');
    app.style.top=top?top+'px':'';
    app.classList.add('vv');
    const kb=typing&&baseH-h>120;
    if(kb!==document.body.classList.contains('kb-open')){
      document.body.classList.toggle('kb-open',kb);
      if(kb&&document.activeElement===input)scrollChat();
    }
    if(kb){const el=document.activeElement;if(el.closest('.sheet'))el.scrollIntoView({block:'center'});}
  }
  const req=()=>{if(!raf)raf=requestAnimationFrame(fit);};
  if(vv){vv.addEventListener('resize',req);vv.addEventListener('scroll',req);}
  window.addEventListener('resize',req);
  window.addEventListener('orientationchange',()=>{baseH=0;setTimeout(req,250);setTimeout(req,600);});
  /* belt and braces for browsers without overflow:clip (Safari < 16): undo any sideways scroll */
  const unshift=()=>{if(app.scrollLeft)app.scrollLeft=0;const sc=$('.screens');if(sc&&sc.scrollLeft)sc.scrollLeft=0;};
  document.addEventListener('focusin',e=>{if(isField(e.target)){unshift();setTimeout(()=>{unshift();req();},60);setTimeout(req,400);}});
  document.addEventListener('focusout',()=>setTimeout(()=>{req();if(!isField(document.activeElement)&&(window.scrollY||document.documentElement.scrollTop))window.scrollTo(0,0);},150));
  /* iOS only fires :active styles when a touch listener exists */
  document.addEventListener('touchstart',()=>{},{passive:true});
  fit();
})();

/* --- 2. install --- */
let deferredInstall=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;});
window.addEventListener('appinstalled',()=>{deferredInstall=null;toast('홈 화면에 RoutineTracker를 추가했어요');});
function canOfferInstall(){return IS_WEB&&!isStandalone();}
function installApp(){
  if(deferredInstall){const p=deferredInstall;deferredInstall=null;$('#sheet').hidden=true;p.prompt();p.userChoice&&p.userChoice.then(c=>{if(c&&c.outcome==='accepted')toast('설치를 시작했어요');}).catch(()=>{});return;}
  const steps=IS_IOS
    ?['Safari 아래쪽의 <b>공유 버튼</b>(네모에 위쪽 화살표)을 눌러요.','목록을 올려서 <b>홈 화면에 추가</b>를 눌러요.','오른쪽 위 <b>추가</b>를 누르면 끝이에요.','<span class="muted">Chrome 등 다른 앱에서 열었다면 Safari로 열어주세요.</span>']
    :IS_SAMSUNG
    ?['오른쪽 아래 <b>메뉴(≡)</b>를 눌러요.','<b>현재 페이지 추가</b> → <b>홈 화면</b>을 눌러요.']
    :['오른쪽 위 <b>메뉴(⋮)</b>를 눌러요.','<b>앱 설치</b> 또는 <b>홈 화면에 추가</b>를 눌러요.'];
  $('#sheetBody').innerHTML=`<div class="grab"></div><div class="h2">📲 홈 화면에 앱 설치</div><p class="muted" style="margin:0;font-size:13.5px">설치하면 주소창 없이 앱처럼 열리고, 인터넷이 없어도 열려요.</p>
    <ol class="steps-list">${steps.map(s=>`<li>${s}</li>`).join('')}</ol>
    ${IS_IOS?'<p class="muted" style="margin:0;font-size:12.5px">홈 화면 앱은 Safari와 저장 공간이 따로예요. Safari에서 쓰던 기록은 백업 후 앱에서 불러오세요.</p>':''}
    <button class="btn ghost" data-act="closesheet">닫기</button>`;
  $('#sheet').hidden=false;
}
document.addEventListener('click',e=>{if(e.target.closest('[data-act="install"]'))installApp();});
if(isStandalone()&&navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{});

/* --- 3. service worker (only on http/https; a double-clicked local file just works without it) --- */
if(IS_WEB&&'serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('./service-worker.js').then(reg=>{
      const ask=w=>toast('새 버전이 준비됐어요',{label:'업데이트',fn:()=>w.postMessage({type:'SKIP_WAITING'})},12000);
      if(reg.waiting&&navigator.serviceWorker.controller)ask(reg.waiting);
      reg.addEventListener('updatefound',()=>{const w=reg.installing;if(w)w.addEventListener('statechange',()=>{if(w.state==='installed'&&navigator.serviceWorker.controller)ask(w);});});
      document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')reg.update().catch(()=>{});});
    }).catch(()=>{});
    /* reload only when an update replaces a running version, never on the very first install */
    const hadController=!!navigator.serviceWorker.controller;let reloading=false;
    navigator.serviceWorker.addEventListener('controllerchange',()=>{if(!hadController||reloading)return;reloading=true;location.reload();});
  });
}

setTimeout(maybeGreet,700);
})();
